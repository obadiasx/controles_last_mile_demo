import uuid
from typing import List

from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, contains_eager
from sqlalchemy import select

from backend.app.models.produtos import Produto
from backend.app.models.unidades import UnidadeProduto
from backend.app.models.solicitacoes_dia_itens import SolicitacaoDiaItem
from backend.app.models.users import User
from backend.app.schemas.solicitacoes_dia_itens import (
    ItemSolicitacaoCreate,
    ItemSolicitacaoUpdate,
    RegistroCompraBaixa
)


class SolicitacaoItemService:

    @staticmethod
    async def _get_item_com_relacionamentos(db: AsyncSession, item_id: uuid.UUID):
        """Método auxiliar para buscar item com unidade_info carregada."""
        stmt = (
            select(SolicitacaoDiaItem)
            .where(SolicitacaoDiaItem.id == item_id)
            .options(
                selectinload(SolicitacaoDiaItem.unidade_info),
                selectinload(SolicitacaoDiaItem.produto),
                selectinload(SolicitacaoDiaItem.fornecedor)
            )
        )

        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    async def incluir_item(db: AsyncSession, item_in: ItemSolicitacaoCreate):
        # 1. Busca produto para regra de preço teto
        produto = await db.get(Produto, item_in.produto_codigo)
        if not produto:
            raise HTTPException(status_code=404, detail="Produto não encontrado")

        # 2. Instancia o novo item
        novo_item = SolicitacaoDiaItem(
            **item_in.model_dump(),
            valor_maximo_aceitavel=produto.valor_maximo_aceitavel,
            comprado=False,
            valor_liberado=False
        )

        db.add(novo_item)
        await db.commit()
        await db.refresh(novo_item)

        # 3. Retorna com relacionamentos carregados para evitar erro de Greenlet no Pydantic
        return await SolicitacaoItemService._get_item_com_relacionamentos(db, novo_item.id)

    @staticmethod
    async def excluir_item(db: AsyncSession, item_id: uuid.UUID):
        item = await db.get(SolicitacaoDiaItem, item_id)
        if not item:
            raise HTTPException(status_code=404, detail="Item não encontrado")

        # REGRA: Não permite excluir se o Cassiano já tiver dado baixa
        if item.comprado:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Não é possível excluir um item já comprado."
            )

        await db.delete(item)
        await db.commit()
        return None

    @staticmethod
    async def registrar_baixa(db: AsyncSession, item_id: uuid.UUID, dados: RegistroCompraBaixa):
        item = await SolicitacaoItemService._get_item_com_relacionamentos(db, item_id)
        if not item:
            raise HTTPException(status_code=404, detail="Item não encontrado.")

        # # --- REGRA 0: Proteção contra Duplicidade ---
        # if item.comprado:
        #     raise HTTPException(
        #         status_code=status.HTTP_400_BAD_REQUEST,
        #         detail="Este item já foi baixado e não permite um novo registro de compra."
        #     )

        # REGRA 1: Trava de Preço (Limitador)
        if dados.valor_unitario > item.valor_maximo_aceitavel and not item.valor_liberado:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Valor ultrapassa o limite permitido. Requer liberação administrativa."
            )

        # --- REGRA 2: Verificação de Unidade e Peso (Nova) ---
        # 1. Descobrir o peso do que foi SOLICITADO originalmente (Peso Alvo)
        peso_alvo = item.peso_total_calculado

        # 2. Descobrir o peso do que está sendo COMPRADO agora
        # Precisamos buscar o fator de conversão da unidade que o comprador escolheu
        stmt = select(UnidadeProduto).where(
            UnidadeProduto.codigo == item.produto_codigo,
            UnidadeProduto.unidade == dados.unidade_comprada
        )
        res = await db.execute(stmt)
        unidade_info_comprada = res.scalar_one_or_none()

        if not unidade_info_comprada:
            raise HTTPException(status_code=400, detail="Unidade comprada inválida para este produto.")

        peso_comprado = float(dados.quantidade_adquirida) * float(unidade_info_comprada.qtde_kg)

        # 3. Validação dos 10% (Desperdício)
        limite_maximo = peso_alvo * 1.10
        if peso_comprado > limite_maximo:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Compra excede o limite de 10% de peso \
                    (Máx: {limite_maximo:.2f}kg, Tentativa: {peso_comprado:.2f}kg)."
            )

        # Atualização dos campos financeiros e de fornecedor
        item.fornecedor_id = dados.fornecedor_id
        item.quantidade_adquirida = dados.quantidade_adquirida
        item.unidade_comprada = dados.unidade_comprada
        item.valor_unitario = dados.valor_unitario
        item.comprado = True
        item.data_vencimento = dados.data_vencimento
        item.forma_pagamento = dados.forma_pagamento
        item.observacao = getattr(dados, 'observacao', None)

        await db.commit()
        return await SolicitacaoItemService._get_item_com_relacionamentos(db, item.id)

    @staticmethod
    async def atualizar_item(db: AsyncSession, item_id: uuid.UUID, item_up: ItemSolicitacaoUpdate, current_user: User):
        item = await SolicitacaoItemService._get_item_com_relacionamentos(db, item_id)
        if not item:
            raise HTTPException(status_code=404, detail="Item não encontrado")

        if item.comprado:
            raise HTTPException(status_code=403, detail="Item finalizado não permite alterações.")

        dados_update = item_up.model_dump(exclude_unset=True)

        # Regra de Permissão por Role
        if "valor_liberado" in dados_update:
            if current_user.role.name not in ["financeiro", "administrador"]:
                raise HTTPException(status_code=403, detail="Apenas o financeiro pode liberar valores.")

        # REGRA: Validação de Preço contra o teto
        if "valor_unitario" in dados_update and dados_update["valor_unitario"] is not None:
            v_unitario = dados_update["valor_unitario"]
            liberado = dados_update.get("valor_liberado", item.valor_liberado)
            if v_unitario > item.valor_maximo_aceitavel and not liberado:
                raise HTTPException(status_code=400, detail="Preço acima do teto permitido.")

        for campo, valor in dados_update.items():
            setattr(item, campo, valor)

        await db.commit()
        return item

    @staticmethod
    async def listar_por_solicitacao(db: AsyncSession, solicitacao_id: uuid.UUID) -> List[SolicitacaoDiaItem]:
        """
        Retorna todos os itens de uma solicitação específica.
        Carrega unidade_info para permitir o cálculo de peso_total no Schema.
        """
        stmt = (
            select(SolicitacaoDiaItem)
            .join(SolicitacaoDiaItem.produto)
            .where(SolicitacaoDiaItem.solicitacao_id == solicitacao_id)
            .order_by(
                SolicitacaoDiaItem.comprado.asc(),  # False (0) antes de True (1)
                Produto.descricao.asc()  # Ordem alfabética A-Z
            )
            .options(
                selectinload(SolicitacaoDiaItem.unidade_info),
                selectinload(SolicitacaoDiaItem.fornecedor),
                # Já que fizemos o join, podemos usar o que já foi carregado
                contains_eager(SolicitacaoDiaItem.produto)
            )
        )
        result = await db.execute(stmt)
        return list(result.scalars().all())
