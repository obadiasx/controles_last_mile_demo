from datetime import datetime, timedelta
from typing import Optional, Sequence

from sqlalchemy import update as sql_update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from backend.app.models.conferencia import ConferenciaItem
from backend.app.models.origem import ItemSC
from backend.app.models.divergencias import Divergencia
from backend.app.schemas.conferencia import (StatusConferencia, ConferenciaItemCreate,
                                             ConferenciaItemUpdate)


class ConferenciaCRUD:
    """
    Classe de Repositório (CRUD) para a entidade ConferenciaItem.
    """

    @staticmethod
    async def get_items(
            db: AsyncSession,
            skip: int = 0,
            limit: int = 100,
            status: Optional[StatusConferencia] = None,
            fornecedor: Optional[str] = None,
            produto: Optional[str] = None
    ) -> Sequence[ConferenciaItem]:
        """
        Listagem de Pedidos: Lista pedidos com status Pendente ou Divergente
        Permite filtrar por status, fornecedor e produto.
        """

        # Filtros baseados na regra: Pendente ou Divergente
        query = select(ConferenciaItem).order_by(ConferenciaItem.data_criacao.desc())

        if status:
            query = query.filter(ConferenciaItem.status_conferencia == status.value)
        else:
            # Regra padrão: Lista apenas Pendente ou Divergente
            query = query.filter(
                (ConferenciaItem.status_conferencia == StatusConferencia.PENDENTE.value) |
                (ConferenciaItem.status_conferencia == StatusConferencia.DIVERGENTE.value)
            )

        # Lógica de filtro para Fornecedor
        if fornecedor:
            # Filtro case-insensitive (ilike) com curinga (%) para LIKE
            query = query.filter(ConferenciaItem.fornecedor.ilike(f'%{fornecedor}%'))

        # Lógica de filtro para Produto
        if produto:
            # Filtro case-insensitive (ilike) com curinga (%) para LIKE
            query = query.filter(ConferenciaItem.produto.ilike(f'%{produto}%'))

        query = query.offset(skip).limit(limit)
        result = await db.execute(query)
        return result.scalars().all()

    @staticmethod
    async def get_item_by_pedido_item(db: AsyncSession, pedido_id: int, item_num: int) -> Optional[ConferenciaItem]:
        """
        Busca um item de conferência pelo NUMPED e ITEM.
        Usado para checagem de duplicidade antes da importação.
        """
        result = await db.execute(
            select(ConferenciaItem).filter(
                (ConferenciaItem.pedido_id == pedido_id) &
                (ConferenciaItem.item == item_num)
            )
        )
        return result.scalars().first()

    @staticmethod
    async def sync_from_origem(db_local: AsyncSession, db_origem: AsyncSession, dias_retroativos: int) -> dict:
        """
        Sincroniza dados da tabela ITENSC (Origem) para conferencia_items (Local).
        """
        data_limite = datetime.now().date() - timedelta(days=dias_retroativos)
        # Converte data_limite para datetime para comparação com data_criacao (que é DateTime)
        data_limite_dt = datetime.combine(data_limite, datetime.min.time())

        # 1. PRÉ-SINCRONIZAÇÃO: Atualizar para CANCELADO=TRUE
        # Filtro: status_conferencia = 'Pendente' E data_criacao >= data retroativa
        cancel_stmt = sql_update(ConferenciaItem).where(
            (ConferenciaItem.status_conferencia == StatusConferencia.PENDENTE.value) &
            (ConferenciaItem.data_criacao >= data_limite_dt)
        ).values(cancelado=True)
        cancel_result = await db_local.execute(cancel_stmt)
        itens_cancelados_count = cancel_result.rowcount  # Contagem de itens marcados como cancelados

        # 2. Realizar SELECT no Banco de Dados de Origem
        origem_query = select(
            ItemSC.numped,
            ItemSC.item,
            ItemSC.qtde,
            ItemSC.peso,
            ItemSC.totkg,
            ItemSC.un,
            ItemSC.dtmovim,
            ItemSC.fantasia,
            ItemSC.descricao
        ).where(ItemSC.dtmovim >= data_limite)

        origem_result = await db_origem.execute(origem_query)
        itens_origem = origem_result.all()

        itens_importados_count = 0
        itens_duplicados_count = 0
        itens_revalidados_count = 0  # Contagem de itens que voltaram para cancelado=False

        # 2. Processar e Inserir/Atualizar cada linha no DB Local
        for item_origem in itens_origem:

            # Checagem de Duplicidade (NUMPED e ITEM)
            pedido_id = item_origem.numped

            existing_item = await ConferenciaCRUD.get_item_by_pedido_item(
                db_local,
                pedido_id,
                item_origem.item
            )

            if existing_item:
                itens_duplicados_count += 1

                # Regra 2: Se o item existir, alterar o cancelado para false
                if existing_item.cancelado:
                    update_stmt = sql_update(ConferenciaItem).where(
                        (ConferenciaItem.pedido_id == pedido_id) &
                        (ConferenciaItem.item == item_origem.item)
                    ).values(cancelado=False)

                    await db_local.execute(update_stmt)
                    itens_revalidados_count += 1

                continue  # Pula a inserção (regra: se existir, não fazer nada)

            try:
                # Regra 3: Mapeamento e Criação do Objeto
                new_item = ConferenciaItem(
                    # Mapeamento
                    pedido_id=pedido_id,
                    fornecedor=item_origem.fantasia if item_origem.fantasia else "N/A",
                    produto=item_origem.descricao if item_origem.descricao else "Produto Desconhecido",
                    quantidade_esperada=item_origem.qtde if item_origem.qtde else 0.0,
                    item=item_origem.item,
                    peso=item_origem.peso if item_origem.peso else 0.0,
                    peso_total=item_origem.totkg if item_origem.totkg else 0.0,
                    unidade=item_origem.un,
                    # Metadados
                    data_criacao=datetime.combine(item_origem.dtmovim,
                                                  datetime.min.time()) if item_origem.dtmovim else datetime.now(),
                    # Padrões
                    cancelado=False,
                    quantidade_fisica=0.0,
                    status_conferencia=StatusConferencia.PENDENTE.value,
                    observacoes=None
                )

                db_local.add(new_item)
                itens_importados_count += 1

            except Exception as e:
                # Log de erro para itens individuais, para não parar o loop
                print(f"Erro ao processar item {pedido_id}-{item_origem.item}: {e}")

        await db_local.commit()

        return {
            "total_encontrado_origem": len(itens_origem),
            "total_importado": itens_importados_count,
            "total_duplicado_ignorado": itens_duplicados_count,
            "total_cancelado_inicialmente": itens_cancelados_count,
            "total_revalidado": itens_revalidados_count,
            "data_inicio_busca": data_limite.isoformat()
        }

    @staticmethod
    async def get_item(db: AsyncSession, item_id: int, pedido_id: int) -> Optional[ConferenciaItem]:
        """
        Busca um item de conferência pelo ID.
        """
        result = await db.execute(select(ConferenciaItem).
                                  filter(ConferenciaItem.pedido_id == pedido_id and ConferenciaItem.item == item_id))
        return result.scalars().first()

    @staticmethod
    async def create_item(db: AsyncSession, item_data: ConferenciaItemCreate) -> ConferenciaItem:
        """
        Cria novo registro de conferência
        """
        db_item = ConferenciaItem(**item_data.model_dump())
        db.add(db_item)
        await db.commit()
        await db.refresh(db_item)
        return db_item

    @staticmethod
    async def update_item(db: AsyncSession, item_id: int, pedido_id: int, item_update: ConferenciaItemUpdate) \
            -> Optional[ConferenciaItem]:
        """
        II.6 Ação Opcional (Botão "Atualizar"): Atualiza campos da conferência.
        """
        update_data = item_update.model_dump(exclude_unset=True)
        if not update_data:
            return await ConferenciaCRUD.get_item(db, item_id, pedido_id)  # Nenhum dado para atualizar

        # 🔹 Ignorar divergencia_id se for None ou 0
        if 'divergencia_id' in update_data and (update_data['divergencia_id'] in [None, 0]):
            update_data.pop('divergencia_id')

        # 🔹 Converte Enum Pydantic -> Enum SQLAlchemy (se necessário)
        if 'status_conferencia' in update_data:
            update_data['status_conferencia'] = update_data['status_conferencia'].value

        # 🔹 Corrigir a expressão do WHERE (usar '&' em vez de 'and')
        stmt = (
            sql_update(ConferenciaItem)
            .where(
                (ConferenciaItem.pedido_id == pedido_id) &
                (ConferenciaItem.item == item_id)
            )
            .values(**update_data)
            .returning(ConferenciaItem)
        )

        updated_item = await db.scalar(stmt)
        await db.commit()

        return updated_item

    @staticmethod
    async def get_divergencias(db: AsyncSession) -> Sequence[Divergencia]:
        """
        Retorna a lista de todas as divergências cadastradas (id e descricao).
        """
        # Seleciona o modelo Divergencia
        query = select(Divergencia).order_by(Divergencia.descricao)

        result = await db.execute(query)
        # O .scalars().all() retorna objetos Divergencia que serão validados pelo Pydantic
        return result.scalars().all()
