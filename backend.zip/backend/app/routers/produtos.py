# backend/app/routers/produtos.py
from typing import List

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.database import get_origem_db_session, get_local_db_session
from backend.app.core.dependencies import get_produto_service
from backend.app.models.users import User
from backend.app.repositories.produtos import ProdutoCRUD
from backend.app.routers.deps import require_products_update_maximum_acceptable
from backend.app.schemas.produtos import ProdutoUpdate, Produto
from backend.app.services.produtos import ProdutoService

router = APIRouter()

db_local_dependency = Depends(get_local_db_session)
db_origem_dependency = Depends(get_origem_db_session)


@router.patch(
    "/{codigo}",
    response_model=Produto,
    summary="Atualiza o valor máximo aceitável para um produto local.",
)
async def atualizar_valor_maximo_produto(
        codigo: int,
        produto_update: ProdutoUpdate,
        _user: User = Depends(require_products_update_maximum_acceptable),
        db: AsyncSession = db_local_dependency
):
    """
    Permite a atualização do campo de regra de negócio 'valor_maximo_aceitavel'
    de um produto específico. Este campo não é atualizado pela sincronização.
    """
    updated_item = await ProdutoCRUD.update_valor_maximo(db, codigo, produto_update)
    if not updated_item:
        raise HTTPException(status_code=404, detail=f"Produto com código {codigo} não encontrado.")
    return updated_item


@router.get(
    "/search",
    response_model=List[Produto],
    summary="Busca Produtos por Descrição (Autocomplete)"
)
async def search_produtos_autocomplete(
        q: str = Query(..., min_length=2, max_length=50),
        limit: int = Query(10, gt=0, le=50),
        db_local: AsyncSession = Depends(get_local_db_session),
        produto_service: ProdutoService = Depends(get_produto_service)
):
    try:
        produtos = await produto_service.get_autocomplete_results(
            db_local=db_local,
            search_term=q,
            limit=limit
        )
        return produtos
    except Exception:
        # ... tratamento de erro
        raise HTTPException(status_code=500, detail="Erro interno ao realizar a busca de produtos.")
