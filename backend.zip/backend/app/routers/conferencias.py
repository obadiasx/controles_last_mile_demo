from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.database import get_origem_db_session, get_local_db_session
from backend.app.core.security import get_current_user_id
from backend.app.models.users import User
from backend.app.repositories.conferencia import ConferenciaCRUD
from backend.app.routers.deps import (
    require_sync_and_update,
    require_list_conference_items,
    require_view_conference_details,
    require_list_divergences
)
from backend.app.schemas.conferencia import (ConferenciaItem, ConferenciaItemCreate, ConferenciaItemUpdate,
                                             StatusConferencia,
                                             SincronizacaoRequest, Divergencia)

router = APIRouter()

# Dependências
db_local_dependency = Depends(get_local_db_session)
db_origem_dependency = Depends(get_origem_db_session)
auth_dependency = Depends(get_current_user_id)


@router.post(
    "/sincronizar",
    summary="Acessa DB de Origem e importa pedidos recentes para conferência.",
    # Dependência removida, agora injetamos o user_id
)
async def sincronizar_pedidos(
        body_params: SincronizacaoRequest,
        _current_user_id: str = auth_dependency,
        db_local: AsyncSession = db_local_dependency,  # DB Local para escrita
        db_origem: AsyncSession = db_origem_dependency  # DB de Origem para leitura
):
    """
    Realiza a busca no DB de Origem (`ITENSC`) por pedidos com `DTMOVIM >= (Hoje - X dias)`
    e insere novos itens em `conferencia_items`, ignorando duplicados (baseado em NUMPED e ITEM).
    """
    try:
        dias = body_params.dias_retroativos
        # Você pode usar o current_user_id aqui para auditoria, se necessário
        # print(f"Sincronização iniciada pelo usuário ID: {current_user_id}")
        resultado = await ConferenciaCRUD.sync_from_origem(db_local, db_origem, dias)
        return {
            "message": "Sincronização concluída.",
            "detalhes": resultado
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro durante a sincronização: {str(e)}"
        )


@router.get(
    "/pedidos",
    response_model=List[ConferenciaItem],
    summary="Listagem de Pedidos de Compra Pendentes/Divergentes",
)
async def list_pedidos_conferencia(
        _current_user: User = Depends(require_list_conference_items),
        db: AsyncSession = db_local_dependency,
        skip: int = 0,
        limit: int = 500,
        status_filtro: Optional[StatusConferencia] = None,
        fornecedor_filtro: Optional[str] = None,
        produto_filtro: Optional[str] = None
):
    """
    Lista todos os pedidos de compra em status 'Pendente' ou 'Divergente'.
    """
    items = await ConferenciaCRUD.get_items(db,
                                            skip=skip,
                                            limit=limit,
                                            status=status_filtro,
                                            fornecedor=fornecedor_filtro,
                                            produto=produto_filtro
                                            )
    return items


@router.get(
    "/pedidos/{item_id}",
    response_model=ConferenciaItem,
    summary="Tela de Detalhes: Exibe Item específico para Conferência",
)
async def get_pedido_details(
        item_id: int,
        _current_user: User = Depends(require_view_conference_details),
        db: AsyncSession = Depends(get_local_db_session)
):
    """
    Busca um item de conferência específico.
    """
    item = await ConferenciaCRUD.get_item(db, item_id)

    if not item:
        raise HTTPException(status_code=404, detail="Item de Conferência não encontrado.")
    return item


@router.post(
    "/pedidos",
    response_model=ConferenciaItem,
    status_code=status.HTTP_201_CREATED,
    summary="Cria Novo Item de Conferência (Simula CID)",
)
async def create_new_pedido(
        item_data: ConferenciaItemCreate,
        _current_user_id: str = auth_dependency,  # Injeta a autenticação
        db: AsyncSession = db_local_dependency
):
    """
    Cria um novo registro para conferência, tipicamente gerado por um sistema CID/ERP.
    """
    return await ConferenciaCRUD.create_item(db, item_data)


@router.patch(
    "/pedidos/{item_id}",
    response_model=ConferenciaItem,
    summary="Atualização da Quantidade Física e Status",
)
async def update_conferencia_item(
        item_id: int,
        pedido_id: int,
        item_update: ConferenciaItemUpdate,
        _current_user: User = Depends(require_sync_and_update),
        db: AsyncSession = Depends(get_local_db_session)
):
    updated_item = await ConferenciaCRUD.update_item(db, item_id, pedido_id, item_update)
    if not updated_item:
        raise HTTPException(status_code=404, detail="Item de Conferência não encontrado.")
    return updated_item


@router.get(
    "/divergencias",
    response_model=List[Divergencia],
    summary="Lista todas as opções de Divergência (ID e Descrição)",
)
async def list_divergencias(
        _current_user: User = Depends(require_list_divergences),
        db: AsyncSession = db_local_dependency,
):
    """
    Endpoint para retornar todos os registros da tabela 'divergencias'.
    """
    divergencias = await ConferenciaCRUD.get_divergencias(db)
    return divergencias
