from typing import List

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.database import get_local_db_session
from backend.app.repositories.fornecedores import FornecedorCRUD
from backend.app.schemas.fornecedores import (
    FornecedorResponse
)

# ... outros imports

router = APIRouter(tags=["Fornecedores"])


# @router.get("/ativos", response_model=List[FornecedorResponse])
# async def listar_fornecedores_ativos(
#         db: AsyncSession = Depends(get_local_db_session)
# ):
#     """
#     Retorna apenas os fornecedores ativos para escolha no aplicativo do comprador.
#     """
#     result = await db.execute(
#         select(Fornecedor).order_by(Fornecedor.fantasia)
#     )
#     return result.scalars().all()


@router.get(
    "/search",
    response_model=List[FornecedorResponse],
    summary="Busca Fornecedores por Fantasia (Autocomplete)"
)
async def search_fornecedores_autocomplete(
        q: str = Query(..., min_length=2, max_length=50),
        limit: int = Query(10, gt=0, le=50),
        db: AsyncSession = Depends(get_local_db_session)
):
    try:
        fornecedores = await FornecedorCRUD.search_autocomplete(
            db=db,
            search_term=q,
            limit=limit
        )
        return fornecedores
    except Exception:
        # Logar o erro real aqui seria ideal
        raise HTTPException(
            status_code=500,
            detail="Erro interno ao realizar a busca de fornecedores."
        )
