import uuid
from typing import List

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.core.database import get_local_db_session
from backend.app.models.users import User
from backend.app.routers.deps import (
    require_update_daily_buy,
    require_delete_daily_buy
)
from backend.app.schemas.solicitacoes_dia_itens import (
    ItemSolicitacaoCreate,
    ItemSolicitacaoUpdate,
    ItemSolicitacaoResponse,
    RegistroCompraBaixa
)
from backend.app.services.solicitacoes_dia_itens import SolicitacaoItemService as service

router = APIRouter(prefix="", tags=["Itens da Solicitação"])


@router.post("/", response_model=ItemSolicitacaoResponse, status_code=status.HTTP_201_CREATED)
async def incluir_item(
        item_in: ItemSolicitacaoCreate,
        db: AsyncSession = Depends(get_local_db_session),
        _current_user: User = Depends(require_update_daily_buy)
):
    return await service.incluir_item(db, item_in)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
async def excluir_item(
        item_id: uuid.UUID,
        db: AsyncSession = Depends(get_local_db_session),
        _current_user: User = Depends(require_delete_daily_buy)
):
    return await service.excluir_item(db, item_id)


@router.patch("/{item_id}/baixa", response_model=ItemSolicitacaoResponse)
async def registrar_baixa_ceagesp(
        item_id: uuid.UUID,
        dados: RegistroCompraBaixa,
        db: AsyncSession = Depends(get_local_db_session),
        _current_user: User = Depends(require_update_daily_buy)
):
    # O Router apenas chama o serviço e passa o que ele precisa
    return await service.registrar_baixa(db, item_id, dados)


@router.patch("/{item_id}", response_model=ItemSolicitacaoResponse)
async def atualizar_item(
        item_id: uuid.UUID,
        item_up: ItemSolicitacaoUpdate,
        db: AsyncSession = Depends(get_local_db_session),
        current_user: User = Depends(require_update_daily_buy)
):
    return await service.atualizar_item(db, item_id, item_up, current_user)


@router.get("/solicitacao/{solicitacao_id}", response_model=List[ItemSolicitacaoResponse])
async def listar_itens_solicitacao(
    solicitacao_id: uuid.UUID,
    db: AsyncSession = Depends(get_local_db_session),
    _current_user: User = Depends(require_update_daily_buy)
):
    """
    Lista todos os itens vinculados a uma 'Missão do Dia' específica.
    """
    return await service.listar_por_solicitacao(db, solicitacao_id)