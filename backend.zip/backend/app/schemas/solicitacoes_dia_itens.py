import uuid
from datetime import date
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, computed_field

from backend.app.schemas.produtos import ProdutoBase


class ItemSolicitacaoBase(BaseModel):
    produto_codigo: int = Field(..., description="Código do produto vindo do cadastro")
    quantidade: float = Field(..., gt=0)
    unidade: str = Field(..., max_length=6, description="Unidade de medida (ex: KG, UN)")


class ItemSolicitacaoCreate(ItemSolicitacaoBase):
    """Utilizado no POST individual para incluir um item na lista"""
    solicitacao_id: uuid.UUID = Field(..., description="ID da Missão/Solicitação pai")


class ItemSolicitacaoUpdate(BaseModel):
    """Utilizado no PATCH para alterar um item antes da compra"""
    quantidade: Optional[float] = Field(None, gt=0)
    unidade: Optional[str] = Field(None, max_length=6)
    # O comprador usará estes campos no momento da execução:
    valor_unitario: Optional[float] = None
    fornecedor_id: Optional[uuid.UUID] = None
    comprado: Optional[bool] = None  # Flag que trava edições futuras
    valor_liberado: Optional[bool] = None  # Liberação manual do financeiro


class ItemSolicitacaoResponse(ItemSolicitacaoBase):
    id: uuid.UUID
    solicitacao_id: uuid.UUID
    valor_maximo_aceitavel: float  # Persistido no momento da criação para auditoria
    comprado: bool
    valor_liberado: bool
    produto: Optional[ProdutoBase] = None
    peso_total_calculado: float = Field(
        ...,
        description="Peso total em KG calculado automaticamente com base na unidade"
    )


    @computed_field
    @property
    def nome_fornecedor(self) -> Optional[str]:
        # Esse mapeamento exige que o relacionamento 'fornecedor' tenha sido carregado
        return self.fornecedor.fantasia if hasattr(self, 'fornecedor') and self.fornecedor else None

    model_config = ConfigDict(from_attributes=True)


class RegistroCompraBaixa(BaseModel):
    fornecedor_id: int
    quantidade_adquirida: float
    unidade_comprada: str  # Para saber se comprou em KG, CX, etc.
    valor_unitario: float
    data_vencimento: date
    forma_pagamento: str  # boleto, cartão ou em aberto
    observacao: Optional[str] = None
