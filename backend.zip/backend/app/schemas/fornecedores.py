import uuid
from typing import Optional

from pydantic import BaseModel, Field
from pydantic import ConfigDict


class FornecedorBase(BaseModel):
    fantasia: str = Field(..., min_length=2, description="Nome Fantasia do Fornecedor")
    box_complemento: Optional[str] = Field(None, description="Ex: Box 142, Coluna B")
    contato: Optional[str] = None


class FornecedorCreate(FornecedorBase):
    pass


class FornecedorUpdate(BaseModel):
    """
    Schema para atualização parcial (PATCH).
    Todos os campos são opcionais.
    """
    nome: Optional[str] = Field(None, min_length=2, description="Nome do Box ou Fornecedor")
    ativo: Optional[bool] = None
    box_complemento: Optional[str] = Field(None, description="Ex: Box 142, Coluna B")
    contato: Optional[str] = None


class FornecedorResponse(FornecedorBase):
    id: int

    model_config = ConfigDict(from_attributes=True)
