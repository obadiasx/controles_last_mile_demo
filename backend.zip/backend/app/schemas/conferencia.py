from datetime import datetime
from enum import Enum as PyEnum  # Importamos como PyEnum para evitar conflito com o Enum do SQLAlchemy
from typing import Optional

from pydantic import BaseModel, Field
from pydantic import ConfigDict


class StatusConferencia(PyEnum):
    PENDENTE = "Pendente"
    DIVERGENTE = "Divergente"
    CONCLUIDO = "Concluido"


# 1. Base Schema
class ConferenciaItemBase(BaseModel):
    pedido_id: int
    item: int
    fornecedor: str = Field(..., max_length=100)
    produto: str = Field(..., max_length=100)
    quantidade_esperada: float = Field(..., gt=0)
    observacoes: Optional[str] = None
    divergencia_id: Optional[int] = None


# 2. Create Schema
class ConferenciaItemCreate(ConferenciaItemBase):
    quantidade_fisica: int = 0
    status_conferencia: StatusConferencia = StatusConferencia.PENDENTE


# 3. Update Schema
class ConferenciaItemUpdate(BaseModel):
    quantidade_fisica: Optional[int] = None
    observacoes: Optional[str] = None
    divergencia_id: Optional[int] = None 
    status_conferencia: Optional[StatusConferencia] = None

    model_config = ConfigDict(
        from_attributes=True,
    )


# 4. Read/Response Schema
class ConferenciaItem(ConferenciaItemBase):
    quantidade_fisica: int
    status_conferencia: StatusConferencia
    data_criacao: datetime
    data_atualizacao: datetime
    # divergencia_id: int

    class Config:
        from_attributes = True  # ou orm_mode = True no Pydantic v1


# Modelo que define a estrutura do corpo da requisição (Body JSON)
class SincronizacaoRequest(BaseModel):
    # Campo obrigatório que será usado para filtrar os pedidos
    dias_retroativos: int


class DivergenciaBase(BaseModel):
    descricao: str


class Divergencia(DivergenciaBase):
    id: int

    class Config:
        from_attributes = True
