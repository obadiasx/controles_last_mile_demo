# ERP Sabor da Terra
Api rest python fast api para backend do ERP Sabor da Terra

## Execução

Como executar a partir da linha de comando:
```
cd \...\ERP_SabordaTerra
.venv\Scripts\Activate.bat
python -r backend.main
```
